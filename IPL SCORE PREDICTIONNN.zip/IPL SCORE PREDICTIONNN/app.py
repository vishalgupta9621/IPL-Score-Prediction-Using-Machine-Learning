from flask import Flask, render_template, request
import numpy as np
import pickle

# Load the Random Forest Classifier model
lr_regressor = pickle.load(open('lr-model.pkl', 'rb'))

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index-1.html')

@app.route('/report')
def report():
    return render_template('report.html')

@app.route('/predict', methods=['POST'])
def predict():
    temp_array = list()

    if request.method == 'POST':
        
        batting_team = request.form['batting-team']
        bowling_team = request.form['bowling-team']
        
        if batting_team == bowling_team:
            return render_template('index-1.html', error_message="Batting team and Bowling team cannot be the same.")
        
        if batting_team == 'Chennai Super Kings':
            temp_array = temp_array + [1,0,0,0,0,0,0,0]
        elif batting_team == 'Delhi Daredevils':
            temp_array = temp_array + [0,1,0,0,0,0,0,0]
        elif batting_team == 'Kings XI Punjab':
            temp_array = temp_array + [0,0,1,0,0,0,0,0]
        elif batting_team == 'Kolkata Knight Riders':
            temp_array = temp_array + [0,0,0,1,0,0,0,0]
        elif batting_team == 'Mumbai Indians':
            temp_array = temp_array + [0,0,0,0,1,0,0,0]
        elif batting_team == 'Rajasthan Royals':
            temp_array = temp_array + [0,0,0,0,0,1,0,0]
        elif batting_team == 'Royal Challengers Bangalore':
            temp_array = temp_array + [0,0,0,0,0,0,1,0]
        elif batting_team == 'Sunrisers Hyderabad':
            temp_array = temp_array + [0,0,0,0,0,0,0,1]
            
        if bowling_team == 'Chennai Super Kings':
            temp_array = temp_array + [1,0,0,0,0,0,0,0]
        elif bowling_team == 'Delhi Daredevils':
            temp_array = temp_array + [0,1,0,0,0,0,0,0]
        elif bowling_team == 'Kings XI Punjab':
            temp_array = temp_array + [0,0,1,0,0,0,0,0]
        elif bowling_team == 'Kolkata Knight Riders':
            temp_array = temp_array + [0,0,0,1,0,0,0,0]
        elif bowling_team == 'Mumbai Indians':
            temp_array = temp_array + [0,0,0,0,1,0,0,0]
        elif bowling_team == 'Rajasthan Royals':
            temp_array = temp_array + [0,0,0,0,0,1,0,0]
        elif bowling_team == 'Royal Challengers Bangalore':
            temp_array = temp_array + [0,0,0,0,0,0,1,0]
        elif bowling_team == 'Sunrisers Hyderabad':
            temp_array = temp_array + [0,0,0,0,0,0,0,1]
            
        overs = float(request.form['overs'])
        if overs > 20:
            return render_template('index-1.html', error_message="Overs cannot be greater than 20.")
        if overs < 5:
            return render_template('index-1.html', error_message="Overs cannot be less than 5.")

        runs = int(request.form['runs'])
        wickets = int(request.form['wickets'])
        if wickets > 10:
            return render_template('index-1.html', error_message="Wickets cannot be greater than 10.", runs=runs)
        
        runs_in_prev_5 = int(request.form['runs_in_prev_5'])
        wickets_in_prev_5 = int(request.form['wickets_in_prev_5'])
        if wickets_in_prev_5 > 10:
            return render_template('index-1.html', error_message="Wickets in the previous 5 overs cannot be greater than 10.", runs=runs)
        
        if runs_in_prev_5 > runs:
            return render_template('index-1.html', error_message="Runs in the previous 5 overs cannot be greater than total runs.", runs=runs)

        if wickets == 10 or wickets_in_prev_5 == 10:
            return render_template('index-1.html', error_message="Cannot predict as all wickets have fallen.", runs=runs)

        if wickets_in_prev_5 > wickets:
            return render_template('index-1.html', error_message="Wickets in the previous 5 overs cannot be greater than total wickets.", runs=runs)

        temp_array = temp_array + [overs, runs, wickets, runs_in_prev_5, wickets_in_prev_5]
        
        data = np.array([temp_array])
        my_prediction = int(lr_regressor.predict(data)[0])
              
        return render_template('result-1.html', lower_limit=my_prediction-10, upper_limit=my_prediction+5)

if __name__ == '__main__':
    app.run(debug=True)
